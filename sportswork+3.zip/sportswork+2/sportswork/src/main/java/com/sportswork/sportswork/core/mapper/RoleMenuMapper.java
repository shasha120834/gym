package com.sportswork.sportswork.core.mapper;

import com.sportswork.sportswork.core.help.RoleMenu;



public interface RoleMenuMapper {
    void addRoleMenu(RoleMenu roleMenu);
    void deleteRoleMenu(String id);
    long getCount();
}
