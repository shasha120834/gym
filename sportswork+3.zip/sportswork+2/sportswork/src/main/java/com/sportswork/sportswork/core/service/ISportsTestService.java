package com.sportswork.sportswork.core.service;

import com.sportswork.sportswork.core.entity.SportsTest;

import java.util.List;

/**
 * @author 
 * @date 2022/3/6 21:32
 * @description
 */
public interface ISportsTestService {
    void addSportsTest(SportsTest sportsTest);
    SportsTest getSportsTest(String id);
    List<SportsTest> getAllSportsTests();
    void deleteSportsTest(String id);
    void setSportsTest(SportsTest sportsTest);
    long getCount();
}
