package com.sportswork.sportswork.core.service;

import com.sportswork.sportswork.core.entity.TestRecord;

import java.util.List;

/**
 * @author
 * @date 2022/3/6 21:36
 * @description
 */
public interface ITestRecordService {
    void addTestRecord(TestRecord testRecord);
    TestRecord getTestRecord(String id);
    List<TestRecord> getAllTestRecords();
    void deleteTestRecord(String id);
    void setTestRecord(TestRecord testRecord);
    long getCount();
}
