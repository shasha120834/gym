package com.sportswork.sportswork.core.mapper;

import com.sportswork.sportswork.core.entity.SportsTest;

import java.util.List;


public interface SportsTestMapper {
    void addSportsTest(SportsTest sportsTest);
    SportsTest getSportsTest(String id);
    List<SportsTest> getAllSportsTests();
    void deleteSportsTest(String id);
    void setSportsTest(SportsTest sportsTest);
    long getCount();
}
