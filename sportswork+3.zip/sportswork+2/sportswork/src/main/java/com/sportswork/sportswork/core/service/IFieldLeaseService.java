package com.sportswork.sportswork.core.service;

import com.sportswork.sportswork.core.entity.FieldLease;
import com.sportswork.sportswork.core.service.dto.FieldLeaseDTO;

import java.util.List;

/**
 * @author cpt202
 * @date 2022/3/6 15:43
 * @description
 */
public interface IFieldLeaseService {
    void addFieldLease(FieldLeaseDTO fieldLeaseDTO);
    FieldLease getFieldLease(String id);
    List<FieldLease> getFieldLeaseByFieldNameLikeOrStudentNumber(String fieldName, String studentNumber);
    List<FieldLease> getAllFieldLeases();
    void deleteFieldLease(String id);
    void setFieldLease(FieldLease fieldLease);
    long getCount();
}
