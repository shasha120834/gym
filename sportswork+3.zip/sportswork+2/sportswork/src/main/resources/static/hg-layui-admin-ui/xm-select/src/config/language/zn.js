export default {
	tips: '请选择',
	empty: '暂无数据',
	searchTips: '请选择',
	toolbar: {
		ALL: '全选',
		CLEAR: '清空',
		REVERSE: '反选',
		SEARCH: '搜索',
	}
}