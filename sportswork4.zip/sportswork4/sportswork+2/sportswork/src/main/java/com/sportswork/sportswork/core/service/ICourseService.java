package com.sportswork.sportswork.core.service;

import com.sportswork.sportswork.core.entity.Course;

import java.util.List;

/**
 * @author cpt202
 * @date 2022/3/6 15:53
 * @description
 */
public interface ICourseService {
    void addCourse(Course course);
    void deleteCourse(String courseId);
    void setCourse(Course course);
    List<Course> getAllCourses();
    Course getCourse(String courseId);
    Course getCourseByNumber(String number);
}
