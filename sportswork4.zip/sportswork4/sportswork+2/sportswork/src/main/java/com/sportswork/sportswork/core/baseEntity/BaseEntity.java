package com.sportswork.sportswork.core.baseEntity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @author
 * @date 2022/3/19 12:11
 * @description
 */
@Data
@Accessors(chain = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class BaseEntity implements Serializable {
    /**
     * 全局唯一Id
     */

    protected String id;
}
