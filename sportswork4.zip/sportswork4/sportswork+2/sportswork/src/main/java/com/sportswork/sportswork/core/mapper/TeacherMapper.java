package com.sportswork.sportswork.core.mapper;

import com.sportswork.sportswork.core.entity.Teacher;

import java.util.List;


public interface TeacherMapper {
    void addTeacher(Teacher teacher);
    Teacher getTeacher(String id);
    Teacher getTeacherByNumber(String number);
    List<Teacher> getAllTeachers();
    void deleteTeacher(String id);
    void setTeacher(Teacher teacher);
    long getCount();
}
