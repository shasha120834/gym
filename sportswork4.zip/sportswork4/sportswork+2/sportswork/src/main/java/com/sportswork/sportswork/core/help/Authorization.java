package com.sportswork.sportswork.core.help;


public class Authorization {
}
