package com.sportswork.sportswork.core.mapper;

import com.sportswork.sportswork.core.entity.GameEnroll;

import java.util.List;


public interface GameEnrollMapper {
    void addGameEnroll(GameEnroll gameEnroll);
    GameEnroll getGameEnroll(String id);
    List<GameEnroll> getAllGameEnrolls();
    void deleteGameEnroll(String id);
    void setGameEnroll(GameEnroll gameEnroll);
    long getCount();
}
