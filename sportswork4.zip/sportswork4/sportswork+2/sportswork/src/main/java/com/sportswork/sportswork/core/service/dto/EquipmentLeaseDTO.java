package com.sportswork.sportswork.core.service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.experimental.Accessors;


@Data
@AllArgsConstructor
@RequiredArgsConstructor
@Accessors(chain = true)
public class EquipmentLeaseDTO {
    private String studentNumber;
    private String equipmentId;
    private int number;
}
