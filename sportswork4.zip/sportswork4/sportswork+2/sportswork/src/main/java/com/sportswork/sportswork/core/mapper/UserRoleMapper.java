package com.sportswork.sportswork.core.mapper;

import com.sportswork.sportswork.core.entity.UserRole;


public interface UserRoleMapper {
    void addUserRole(UserRole userRole);
    void delUserRole(String id);
    void delUserRoleByUser(String userId);
    long getCount();
}
