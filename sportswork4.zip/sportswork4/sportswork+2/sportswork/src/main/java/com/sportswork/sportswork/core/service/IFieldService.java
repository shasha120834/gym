package com.sportswork.sportswork.core.service;

import com.sportswork.sportswork.core.entity.Field;

import java.util.List;

/**
 * @author cpt202
 * @date 2022/3/6 15:45
 * @description
 */
public interface IFieldService {
    void addField(Field field);
    Field getField(String id);
    List<Field> getFieldByNameLike(String name);
    List<Field> getAllFields();
    void deleteField(String id);
    void setField(Field field);
    long getCount();
}
