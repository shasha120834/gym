package com.sportswork.sportswork.core.service;

import com.sportswork.sportswork.core.entity.GameEnroll;

import java.util.List;

/**
 * @author cpt202
 * @date 2022/3/6 15:58
 * @description
 */
public interface IGameEnrollService {
    void addGameEnroll(GameEnroll gameEnroll);
    GameEnroll getGameEnroll(String id);
    List<GameEnroll> getAllGameEnrolls();
    void deleteGameEnroll(String id);
    void setGameEnroll(GameEnroll gameEnroll);
    long getCount();
}
